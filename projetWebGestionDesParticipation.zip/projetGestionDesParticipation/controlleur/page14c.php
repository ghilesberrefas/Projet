<?php
	require("../trame/auth/EtreAuthentifie.php");
	require('../model/requetesSql.php');

		//print_r($_POST);
	 if(empty($_POST['evenement']) && empty($_POST['personnes']) && empty($_POST['date']) ) {
		echo "string";
		$participations = listParticipations();
		
		require('../view/page20a.php') ;

	}
	else if(isset($_POST['evenement'])  && empty($_POST['personnes']) && empty($_POST['date']) ){
		echo "aaaaaaa" ;
	 	 print_r($_POST);
		$participations=listParticipationsParEvenement($_POST['evenement']) ; 
		require('../view/page20a.php') ; 

	}
	else if(isset($_POST['personnes']) && empty($_POST['evenement']) && empty($_POST['date']) ){
			
		$participations=listParticipationsParPersonne($_POST['personnes']) ; 
		require('../view/page20a.php') ; 

	}
	else if(isset($_POST['date']) && empty($_POST['evenement']) && empty($_POST['personnes']) ){

		$participations=listParticipationsParDate($_POST['date']) ; 
		require('../view/page20a.php') ; 

	}
	else if(isset($_POST['evenement']) && isset($_POST['personnes']) && empty($_POST['date']) ){
	 
		$participations=listParticipationsParEvenementEtPersonnes($_POST['evenement'] ,$_POST['personnes'] ) ; 
		require('../view/page20a.php') ; 

	}
	else if(isset($_POST['evenement']) && isset($_POST['date']) && empty($_POST['personnes']) ){
	 
		$participations=listParticipationsParEvenementEtDate($_POST['evenement'] ,$_POST['date'] ) ; 
		require('../view/page20a.php') ; 

	}
	else if(isset($_POST['personnes']) && isset($_POST['date']) && empty($_POST['evenement']) ){
	 
		$participations=listParticipationsParPersonnesEtDate($_POST['personnes'] ,$_POST['date'] ) ; 
		require('../view/page20a.php') ; 

	}
	else if(isset($_POST['evenement']) && isset($_POST['personnes']) && isset($_POST['date']) ){
	 	echo "aaaaaaaaaaa";
		$participations=listParticipationsParEvenementEtpersonnesEtDate($_POST['evenement'],$_POST['personnes'],$_POST['date']) ; 
		require('../view/page20a.php') ; 

	}

