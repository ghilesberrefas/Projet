<?php
	require('../model/requetesSql.php');
	
	// modification d'une personne 

	if(isset($_POST['prenom']) && isset($_POST['nom'])){
		if(isset($_POST['prenom']) && ! empty($_POST['prenom'])) {

			$db=dbConnect() ; 
		    $req=$db->prepare('UPDATE personnes SET prenom = ? WHERE pid = ?  ') ; 
		    $req->execute(array($_POST['prenom'],$_GET['pid'])) ; 

		    
		}
		if(isset($_POST['nom']) && ! empty($_POST['nom']) ) {
	
			$db=dbConnect() ; 
		    $req=$db->prepare('UPDATE personnes SET nom = ? WHERE pid = ?  ') ; 
		    $req->execute(array($_POST['nom'],$_GET['pid'])) ; 

		    
		}
		$personnes = listPersonnes() ; 	
		require('../view/page8a.php') ; 
	}// modification des types d'identification 
	else if(isset($_POST['nomItypes'])){
		$db=dbConnect() ; 
	    $req=$db->prepare('UPDATE itypes SET nom = ? WHERE tid = ?  ') ; 
	    $req->execute(array($_POST['nomItypes'],$_GET['tid'])) ; 

		$itypes = listItypes() ; 

		require('../view/page11a.php') ; 
	}// modification d'un evenement 
	else if (isset($_POST['intitule']) && isset($_POST['description']) && isset($_POST['dateDebut']) &&
		isset($_POST['dateFin']) && isset($_POST['type']) && isset($_POST['categories']) ) {
		

		if(isset($_POST['intitule']) && ! empty($_POST['intitule'])) {

			$db=dbConnect() ; 
		    $req=$db->prepare('UPDATE evenements SET intitule = ? WHERE eid = ?  ') ; 
		    $req->execute(array($_POST['intitule'],$_GET['eid'])) ; 

		    
		}
		if(isset($_POST['description']) && ! empty($_POST['description']) ) {
	
			$db=dbConnect() ; 
		    $req=$db->prepare('UPDATE evenements SET description = ? WHERE eid = ?  ') ; 
		    $req->execute(array($_POST['description'],$_GET['eid'])) ; 
  		}
		if(isset($_POST['dateDebut']) && ! empty($_POST['dateDebut'])) {

			$db=dbConnect() ; 
		    $req=$db->prepare('UPDATE evenements SET dateDebut = ? WHERE eid = ?  ') ; 
		    $req->execute(array($_POST['dateDebut'],$_GET['eid'])) ; 		    
		}
		if(isset($_POST['dateFin']) && ! empty($_POST['dateFin']) ) {
	
			$db=dbConnect() ; 
		    $req=$db->prepare('UPDATE evenements SET dateFin = ? WHERE eid = ?  ') ; 
		    $req->execute(array($_POST['dateFin'],$_GET['eid'])) ; 
		}



		if(isset($_POST['type']) && ! empty($_POST['type'])) {

			$db=dbConnect() ; 
		    $req=$db->prepare('UPDATE evenements SET type = ? WHERE eid = ?  ') ; 
		    $req->execute(array($_POST['type'],$_GET['eid'])) ; 

		    
		}
		if(isset($_POST['categories']) && ! empty($_POST['categories']) ) {
				
			if($_POST['categories']=='Examens'){
				$cid = 1 ;
			}
			else if($_POST['categories']=='Cours'){
				$cid = 2 ;
			}else{
				$cid = 3 ; 
			}
			$db=dbConnect() ; 
		    $req=$db->prepare('UPDATE evenements SET cid = ? WHERE eid = ?  ') ; 
		    $req->execute(array($cid,$_GET['eid'])) ; 

		   
		}
		$evenement= listEvenement() ; 
		require('../view/page14a.php') ; 

	}// modifier le moyen d'identification d'une personnes 
	else if ( isset( $_GET['identification'] ) && isset( $_POST['valeur1']) && isset( $_GET['ppid'] ) ){

	

			if(isset($_POST['valeur1']) && ! empty($_POST['valeur1'])) {
				$req=readTid($_GET['identification']);
				$data = $req -> fetch(); 
				$tid = $data['tid'] ; 

				$db=dbConnect() ; 
			    $req=$db->prepare('UPDATE identifications SET valeur = ? WHERE pid = ?  AND tid = ?') ; 

			    
			    $req->execute(array($_POST['valeur1'],$_GET['ppid'] , $tid )) ; 

			}
			$identification=listIdentification($_GET['ppid']) ; 

			$db=dbConnect() ; 

			$req=$db->prepare('SELECT pid,nom,prenom FROM personnes where pid = ? '); 
			$pid=$_GET['ppid'] ; 
	
			$req ->execute(array($pid)) ; 
			$personne = $req ; 
				

			require('../view/page17a.php') ; 

	}


	