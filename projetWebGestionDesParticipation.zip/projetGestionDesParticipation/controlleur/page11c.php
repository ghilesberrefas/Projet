<?php
	require('../model/requetesSql.php');
	require("../trame/auth/EtreAuthentifie.php");

//ajout de personnes avec identification 
if (isset($_POST['nom']) AND isset($_POST['prenom'] )){

	addpersonnes ($_POST['nom'],$_POST['prenom']) ; 

	//recuperation de l'tid 
	$db=dbConnect() ; 
    $req=readTid($_POST['identification']);
    $data = $req -> fetch(); 
    $tid = $data['tid'] ; 

    //recuperation de l'pid
    $req1=$db->query('SELECT pid FROM personnes ORDER by pid DESC limit 1')	 ; 
    $data1 = $req1 -> fetch(); 
  	$pid = $data1['pid'] ; 

    

    //ajout des identifiant 
	addIdentification($pid,$tid,$_POST['valeur']) ; 
	//$data1->closeCursor();
	//$data->closeCursor() ; 

	$personnes = listPersonnes() ; 

	require('../view/page8a.php') ; 
} //ajout de type d'idetification 
else if(isset($_POST['nomItypes'])){
	addItypes($_POST['nomItypes']);
	$itypes = listItypes() ; 
	require('../view/page11a.php') ; 

}// ajout d'un evenement 
else if(isset($_POST['intitule']) && isset($_POST['description']) && isset($_POST['dateDebut']) &&
		isset($_POST['dateFin']) && isset($_POST['type']) && isset($_POST['categories']) ){

	if($_POST['categories']=='Examens'){
		$cid = 1 ;
	}
	else if($_POST['categories']=='Cours'){
		$cid = 2 ;
	}else{
		$cid = 3 ; 
	}

	addEvenement($_POST['intitule'],$_POST['description'],$_POST['dateDebut'],$_POST['dateFin'],$_POST['type'],$cid) ;
	$evenement= listEvenement() ; 
	require('../view/page14a.php') ; 


}//ajoute une identification a une perssone 
else if ( isset( $_POST['identification'] ) && isset( $_POST['valeur1']) && isset( $_GET['ppid'] ) ){
	
	//print_r($_GET['ppid']) ;
	//print_r( $_POST['identification']);
	$req=readTid($_POST['identification']);
    $data = $req -> fetch(); 
    $tid = $data['tid'] ; 

	addIdentification($_GET['ppid'],$tid,$_POST['valeur1']) ; 

	$identification=listIdentification($_GET['ppid']) ; 

	$db=dbConnect() ; 

	$req=$db->prepare('SELECT pid,nom,prenom FROM personnes where pid = ? '); 
	$pid=$_GET['ppid'] ; 
	//$pid=2;
	$req ->execute(array($pid)) ; 
	$personne = $req ; 
		

	require('../view/page17a.php') ; 


	
}
