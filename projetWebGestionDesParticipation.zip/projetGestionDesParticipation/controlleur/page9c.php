<?php
	require('../model/requetesSql.php');
	require("../trame/auth/EtreAuthentifie.php"); 
	//supprimer une personne de la liste 
	if(isset($_GET['pid'])){

		detelePersonnes ($_GET['pid']) ;
		deleteIdentification($_GET['pid']) ; 
		$personnes = listPersonnes() ; 
		require('../view/page8a.php') ;

	}//supprimer un type d'identification 

	else if (isset($_GET['tid'])) {

		deleteItypes($_GET['tid']) ;
		$itypes = listItypes() ; 
		require('../view/page11a.php') ; 

	}// supprimer un evenement 
	else if(isset($_GET['eid'])) {
		deleteEvenement($_GET['eid']) ; 
		$evenement= listEvenement() ; 
		require('../view/page14a.php') ;
	}// supprimer un identifient d'une personnes 
	else if(isset($_GET['ppid']) &&  isset($_GET['modifier']) ){


			$req=readTid($_GET['modifier']);
			$data = $req -> fetch(); 
			$tid = $data['tid'] ; 
			$db=dbConnect() ; 
		    $req=$db->prepare('DELETE FROM  identifications WHERE pid = ?  AND tid = ?') ; 
		    $req->execute(array($_GET['ppid'] , $tid )) ; 
			$identification=listIdentification($_GET['ppid']) ; 

			$db=dbConnect() ; 

			$req=$db->prepare('SELECT pid,nom,prenom FROM personnes where pid = ? '); 
			$pid=$_GET['ppid'] ; 
	
			$req ->execute(array($pid)) ; 
			$personne = $req ; 
				

			require('../view/page17a.php') ; 

	}