<?php
require('../model/requetesSql.php');

/*$list = listUser() ; 

while($data = $list->fetch() ){
	echo $data['login'] ." ". $data['role'] . "<br/>"  ; 
}*/
if (isset($_POST['nom']) AND isset($_POST['prenom'] )){

	addpersonnes ($_POST['nom'],$_POST['prenom']) ; 
	//echo "la participation a bien etais pris en conte vous resevrer une confirmation ultérieurement";
}

else{

	echo "else je suis la " ; 
}


$eventOpen  = listEventOpen() ;
$eventClose = listEventClose() ; 

require('../view/page1a.php');


