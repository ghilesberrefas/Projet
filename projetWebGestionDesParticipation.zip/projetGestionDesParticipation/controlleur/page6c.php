<?php
require('../model/requetesSql.php');
// connection a la base de donnée
$bd=dbConnect() ; 

//verification du login 
print_r($_GET['uid']) ; 

$req = $bd->prepare('UPDATE users SET mdp = ? WHERE uid = ? ' ) ; 

if($_POST['mdp'] != $_POST['mdp1'] ){
	echo "mot de passe incorrect" ; 
}
else{
	$mdp_hache=password_hash($_POST['mdp'], PASSWORD_DEFAULT);
	$req -> execute(array($mdp_hache,$_GET['uid'])) ; 
	echo "le mot de passe est bien modifier" ; 
}


$users = listUser() ; 

require('../view/page5a.php') ; 