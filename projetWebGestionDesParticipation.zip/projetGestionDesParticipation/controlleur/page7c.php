<?php
require('../model/requetesSql.php');
// connection a la base de donnée
$bd=dbConnect() ; 

//verification du login 

$req = $bd->prepare('SELECT login FROM users WHERE login = ?') ; 

$req -> execute(array($_POST['login'])) ; 
$data = $req -> fetch();
if($data['login'] == $_POST['login']) {
		$req ->closeCursor() ; 
		echo "le Pseudonyme que vous avez choisie existe déja" ;
		exit(1); 
}
//verification du mot de passe 
if($_POST['mdp'] !=$_POST['mdp1'] ){
		//echo 'Veuillez entrez le meme mot de passe' ; 
	echo "Veuillez entrez le meme mot de passe" ;
	exit(1); 
}
$pass_hache = password_hash($_POST['mdp'], PASSWORD_DEFAULT);



addUser($_POST['login'],$pass_hache,$_POST['role']) ;; 

	$users = listUser() ; 

	require('../view/page5a.php') ; 
	