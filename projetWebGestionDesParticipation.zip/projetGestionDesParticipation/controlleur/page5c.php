<?php
	require("../trame/auth/EtreAuthentifie.php");
	require('../model/requetesSql.php');
	
	try { 
		if($_GET['control']==="gdu"){
			//liste des utilisateur 
			$users = listUser() ; 
			require('../view/page5a.php') ; 
		}else if($_GET['control']==="gdp"){
			//lister les personnes
			
			$personnes = listPersonnes() ; 
			require('../view/page8a.php') ; 
		}else if ($_GET['control']==="gdi"){
			//liste des types d'identification
			
			$itypes = listItypes() ; 
			require('../view/page11a.php') ; 
		}
		else if ($_GET['control']==="gde"){
			
			$evenement= listEvenement() ; 
			require('../view/page14a.php') ; 
		}
		else if ($_GET['control'] === "tableauDeBord"){
			
			$participations = listParticipations() ;
			
			require('../view/page20a.php') ; 
		}
		include("../trame/footer.php");
		
	}
	catch(Exception $e) { 
    	echo 'Erreur : ' . $e->getMessage();
	}

		

