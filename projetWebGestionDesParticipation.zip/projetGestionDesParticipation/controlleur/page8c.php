<?php
	require('../model/requetesSql.php');
	//lister les personnes 
	$personnes = listPersonnes() ; 

	require('../view/page8a.php') ; 
