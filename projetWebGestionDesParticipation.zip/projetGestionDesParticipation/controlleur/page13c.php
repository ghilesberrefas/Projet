<?php
	require('../model/requetesSql.php');
	require("../trame/auth/EtreAuthentifie.php");
	//liste des types d'identification 
	
	//print_r($_GET['pid']) ; 
	$identification=listIdentification($_GET['pid']) ; 

	$db=dbConnect() ; 

	$req=$db->prepare('SELECT pid,nom,prenom FROM personnes where pid = ? '); 
	$pid=$_GET['pid'] ; 
	//$pid=2;
	$req ->execute(array($pid)) ; 
	$personne = $req ; 
		

	require('../view/page17a.php') ; 
