<?php
require('../model/requetesSql.php');

/*$list = listUser() ; 

while($data = $list->fetch() ){
	echo $data['login'] ." ". $data['role'] . "<br/>"  ; 
}*/




$eventOpen = listEventOpen() ;
$eventClose = listEventClose() ; 

require('../view/page1a.php');


