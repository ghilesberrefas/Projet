<?php
	require('../model/requetesSql.php');
	require("../trame/auth/EtreAuthentifie.php");
	//liste des types d'identification 
	$itypes = listItypes() ; 
	if(isset($_GET['pid']) &&  isset($_GET['modifier']) ){
		$pid=$_GET['pid'] ; 
		$identification = $_GET['modifier'] ; 
		require('../view/page19a.php') ; 
	}
	else if(isset($_GET['pid']) ) {
		$pid=$_GET['pid'] ; 
		require('../view/page18a.php') ; 

	}else{

	require('../view/page10a.php') ; 
	}

