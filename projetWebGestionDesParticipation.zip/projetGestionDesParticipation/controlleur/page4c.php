<?php
require('../model/requetesSql.php');
// connection a la base de donnée
$bd=dbConnect() ; 

//Recuperation du mot de passe hashé 

$req = $bd->prepare('SELECT uid,login , mdp , role FROM users WHERE login = ? ');
    $req->execute(array(  $_POST['login'] ));
    $data = $req->fetch();
// Comparaison du pass envoyé via le formulaire avec la base
    $isPasswordCorrect = password_verify($_POST['mdp'], $data['mdp']);

    if (!$data)
    {
        echo 'Mauvais identifiant ou mot de passe !';
    }
    else
    {
        if ($isPasswordCorrect) {
            session_start();
            $_SESSION['uid'] = $data['uid'];
            $_SESSION['login'] = $_POST['login'];
            echo 'Vous êtes connecté !'; 
            if($data['role']=='admin'){
            	require('../view/page4a.php') ; 
        	}
        }
        else {
            echo 'Mauvais identifiant ou mot de passe !';
        }
    }

