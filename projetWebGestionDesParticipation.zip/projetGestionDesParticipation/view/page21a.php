<?php
$title= "GESTION DES TYPES D'IDENTIFICATION" ; 
    		include ("../trame/header.php");
    		$date = listdate() ; 
			$personnes = listPersonnes() ; 
			$evenement= listEvenement() ;

?>		
<div class="row">
	<?php 
		include ("menuGestion.php");
    ?>	
    <div class="container col-md-9" >	


			<h2 id="TableauDeBord">Tableau de bord : </h2>

			<h4>Affichage des participations aux événements : </h4>

		<div class="container-fluide">
			<form action="../controlleur/page14c.php" method="post">
			<div class="d-flex justify-content-around"  >
				<div class="form-group">
					<label for ="evenement"> Par événement : </label>
					
						<select name = "evenement"  class="form-control " id="evenement">
							<option value=""> Choisez un evenement  </option>
							<?php
								
								while($data=$evenement->fetch()){
							?>
										<option value="<?= $data['eid'] ?> "> <?= $data['intitule'] ?>  </option> 
							<?php 
								}
								$evenement->closeCursor() ; 
						     ?> 
						</select> 
				</div>
				
				<div class="form-group">
					<label for ="personnes"> Par Personne : </label>
					
						<select name = "personnes" class="form-control " id="personnes">
							<option value=""> Choisez une personne  </option>
							<?php
								
								while($data=$personnes->fetch()){
							?>
										<option value="<?= $data['pid'] ?> "> <?= $data['nom'] ?>  <?= $data['prenom'] ?> </option> 
							<?php 
								}
								$personnes->closeCursor() ; 
						     ?> 
						</select> 
				
				</div>
				<div class="form-group">
					<label for ="date"> Par dates : </label>
						
						<select name = "date" class="form-control " id="date">
							<option value=""> Choisez une date </option>
							<?php
				
								while($data=$date->fetch()){
							?>
										<option value="<?= $data['date'] ?> "> <?= $data['date'] ?>   </option> 
							<?php 
								}
								$date->closeCursor() ; 
						     ?> 
						</select> 
						
				</div>
			</div>
				<div class="d-flex justify-content-center">
				<button type="submit" class="btn btn-primary ">Valider</button>
				</div>	

			</form>
		</div>