
<?php $title= "Ajout D'un utilisateur" ; 
	include ("../trame/header.php");
?>
	<div class="container">
        <form action="../controlleur/page7c.php" method="post">
        	<div class="form-group form-check">
		       	<p> Dans quel role souhaitez vous ajout l'utilisateur ? </p>	
				<input type="radio" name="role" value="admin" id="administrateur" checked="checked" /> 
				<label for="administrateur">administrateur</label>
				<input type="radio" name="role" value="user" id="user" /> <label for="user">utilisateur</label>
			</div>

			<div class="form-group">
				<label for ="login" > login : </label>
				<input type="text" class="form-control" name="login" id="login">
			</div>
			<div class="form-group">
				<label for ="mdp"> mot de passe : </label>
				<input type="password" class="form-control" name="mdp" id="mdp">
			</div>
			<div class="form-group">
				<label for ="mdp1"> confirmation du mot de passe : </label>
				<input type="password" class="form-control" name="mdp1" id="mdp1">
			</div>

			<button type="submit" class="btn btn-primary">Ajouter</button>
		</form>
     </div>
    </body>
</html>