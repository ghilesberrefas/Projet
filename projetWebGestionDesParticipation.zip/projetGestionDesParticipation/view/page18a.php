
<?php 
	$title= "Ajouter une identification a une PERSONNE " ; 
	include ("../trame/header.php");
?>


<div class="container">							  
	<p> Veuillez indiquer le moyen et la valeur d'identification :    </p>              
	<form action="../controlleur/page11c.php?ppid=<?= $pid ?> " method="post">
				<div class="form-group">
			<label for ="identification"> choisiez un moyen d'identification : </label>
			</div>		
			<div class="form-group row">
				<select name = "identification" class="form-control col-3"id="identification">
				<?php
					
					while($data=$itypes->fetch()){
				?>
	 					<option value="<?= $data['nom'] ?>"> <?= $data['nom'] ?>  </option> 
				<?php 
					}
					$itypes->closeCursor() ; 
			     ?> 
				</select> 

				<label for ="valeur"></label>
				<input type="text" name="valeur" >
			</div>		
			<button type="submit" class="btn btn-primary">Ajouter</button>
	</form>
</div>

<?php 
	include ("../trame/footer.php");
?>