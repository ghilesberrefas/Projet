
<?php 
	$title= "Ajouter un type d'identification" ; 
	include ("../trame/header.php");
?>

<div class="d-flex justify-content-center">
	 
	<form action="../controlleur/page11c.php" method="post">
		<p> Veuillez indiquer le nouveau type d'identification : </p>
		<div class="form-group">
			<label for ="nomItypes"> Nom : </label>
			<input type="text" name="nomItypes"  class="form-control" id="nomItypes"required value="" >
		</div>
			
			<button type="submit" class="btn btn-primary">Ajouter</button>
	</form>
	
</div>

<?php 
	include ("../trame/footer.php");
?>