
<?php 
$title= "MISE A JOUR MOT DE PASSE" ; 
include ("../trame/header.php");
?>
    	 
<div class="container col-3">
        <form action="../controlleur/page6c.php?uid=<?= $_GET['uid'] ?>" method="post">
      
			<div class="form-group">
				<label for ="mdp"> Le nouveau mot de passe : </label>
				<input type="password" class="form-control" name="mdp" id="mdp">
			</div>
			<div class="form-group">
				<label for ="mdp1"> confirmation du mot de passe : </label>
				<input type="password" class="form-control" name="mdp1" id="mdp1">
			</div>

			<button type="submit" class="btn btn-primary">Modifier</button>
		</form>
     </div>
        
<?php 
	include ("../trame/footer.php");
?>