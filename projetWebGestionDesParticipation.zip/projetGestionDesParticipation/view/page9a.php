
<?php 
	$title= "MODIFIER LA PERSONNE" ; 
	include ("../trame/header.php");
?>
		
		
<div class="container col-3">	
	<p> Veuillez indiquer le nouveau nom ou prénom.  </p>  
	<form action="../controlleur/page11c.php" method="post">
			<div class="form-group">
				<label for ="nom"> Nom : </label>
				<input type="text" name="nom" class="form-control" id="nom" required>
			</div>
			<div class="form-group">
				<label for ="prenom"> Prénom : </label>
				<input type="text" name="prenom" class="form-control " id="prenom" required>
			</div>	
			<button type="submit" class="btn btn-primary">Modifier</button>
	</form>
</div>
			
<?php 
	include ("../trame/footer.php");
?>