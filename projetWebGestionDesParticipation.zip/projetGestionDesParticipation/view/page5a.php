
<?php 
	$title= "GESTION DES UTILISATEUR" ; 
	include ("../trame/header.php");
?>
<div class="row">  
	<?php 
	include ("menuGestion.php");
	 ?>		
	<div class="container col-md-8" id="con5">
			<h3>liste des utilisateur : </h3>

		<div class="container col-md-12 ">
			<table class="table">
					<tr>
				        <th>Id</th>
				        <th>Login </th>
				        <th>Role</th>
				        <th>Option</th>
			        </tr>
				<?php
					$i=1 ; 
					while ($data = $users->fetch()){
				?>	
				   <tr>
				   		<td> <?= $i ?>  </td> 
						<td> <?= $data['login'] ?>  </td> 
						<td> <?= $data['role'] ?> </td>
						<td><a href="../view/page7a.php?uid=<?=$data['uid'] ?>">modifier le mot de passe</a></td>
									
				   </tr>
				<?php
					$i++;
				}
					$users->closeCursor() ; 
				?>
			</table>
	   </div>


		<form action="../view/page6a.php" method="post">
			
			<p>Cliquer sur le boton pour ajouter un utilisateur.</p>
			
			<button type="submit" class="btn btn-primary">Ajouter</button>
		</form>		

	</div>
</div> 
<?php 
	include ("../trame/footer.php");
?>
