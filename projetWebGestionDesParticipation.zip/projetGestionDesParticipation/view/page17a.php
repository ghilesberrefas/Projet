

<?php 
	$title= "GESTION DES TYPE D'IDANTIFICATION PAR PERSONNES" ; 
	include ("../trame/header.php");
?>
<div class="row">
	<?php 
		include ("menuGestion.php");
    ?>	
    <div class="container col-md-8" id="con5">	
		<h3>Gestion des identification par personne : </h3>
		<div class="container col-md-12 ">
			<table class="table">
	 	 		 <tr>
			   		<th>Id</th>
			        <th>Nom</th>
			        <th>Valeur </th>
			        <th>Option 1</th>
			        <th>Option 2</th>
		       </tr>
				<?php 
					$data1 = $personne->fetch() ;  
				?>
				<p> <b><?=$data1['nom'] ?>  <?=$data1['prenom'] ?></b> c'est identifier avec : </p>

				<?php
					
					$i=1;
					while ($data = $identification->fetch()){
				?>	
			   <tr>
					<td> <?= $i ?>  </td> 
					<td> <?= $data['nom'] ?> </td>	
					<td> <?= $data['valeur'] ?> </td>
					<td><a href="../controlleur/page12c.php?modifier=<?= $data['nom'] ?>&pid=<?=$data1['pid'] ?>">modifier </a></td>
					<td><a href="../controlleur/page9c.php?modifier=<?= $data['nom'] ?>&ppid=<?=$data1['pid'] ?>">supprimer </a></td>				
			   </tr>
				<?php
						$i++;	
					}
					$identification->closeCursor() ; 
				?>
			</table>
	  	</div>
			<form action="../controlleur/page12c.php?pid=<?=$data1['pid'] ?> " method="post">
				<p>cliquer sur le boton pour ajouter une identification a <?=$data1['nom'] ?>  <?=$data1['prenom'] ?>	 </p>
				<button type="submit" class="btn btn-primary">Ajouter</button>
				<?php $personne->closeCursor() ; ?> 
			</form>	

	</div> 
</div> 	
<?php 
	include ("../trame/footer.php");
?>