
		<?php 
	$title= "Modifier un EVENEMENT" ; 
	include ("../trame/header.php");

		
		
?>
<div class="d-flex justify-content-center">
		<form action="../controlleur/page10c.php?eid=<?= $_GET['eid'] ?>" method="post">
				<p> Veuillez indiquer les informations que vous voulais modifier  </p> 
				<div class="row">
					<div class="form-group">
						<label for ="intitule"> l'intitule : </label>
						<input type="text" name="intitule" class="form-control" required value="" >
					</div>
					<div class="form-group">
						<label for ="description"> description : </label>
						<input type="text" name="description" class="form-control" required value="" >
					</div>
				</div>
				<div class="row">
					<div class="form-group col-12 ">
						<div class="form-group">
								<label for ="type"> type : </label>
						</div>
						<div class="form-group">
							<select name = "type" class="form-control col-3" id="type">
					 					<option value="ouvert"> ouvert  </option> 
					 					<option value="ferme"> ferme  </option> 	
							</select> 
						</div>
					</div>
					<div class="form-group col-12 ">
						<div class="form-group">
								<label for ="categories"> categories : </label>
						</div>
						<div class="form-group">
							<select name = "categories" class="form-control col-3" id="categories">
					 					<option value="Examens"> Examens  </option> 
					 					<option value="Cours"> Cours  </option> 
					 					<option value="TPs"> TPs  </option> 	
							</select> 
						</div>
					</div>
				</div>
				
				<div class="form-group">
					<label for ="dateDebut"> date de debut : </label>
					<input type="datetime-local" name="dateDebut" class="form-control"required value="" >
				</div>
				<div class="form-group">
					<label for ="dateFin"> date de fin : </label>
					<input type="datetime-local" name="dateFin" class="form-control"required value="" >
				</div>

				<button type="submit" class="btn btn-primary">Modifier</button>
		</form>
</div>
<?php 
	include ("../trame/footer.php");
?>