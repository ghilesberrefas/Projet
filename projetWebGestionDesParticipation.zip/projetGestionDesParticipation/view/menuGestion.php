	

	<div class="container col-md-3">
		
		<ul>
			<h4>Menu Gestion:</h4> 
			<li> <a href="../controlleur/page5c.php?control=gdu"> Gestion des utilisateur :</a> </li>
			<li> <a href="../controlleur/page5c.php?control=gdp"> Gestion des personnes :</a></li>
			<li> <a href="../controlleur/page5c.php?control=gdi"> Gestion des types d’identification : </a> </li>
			<li> <a href="../controlleur/page5c.php?control=gde"> Gestin des événements : </a></li> 
			<li><a href="../controlleur/page5c.php?control=tableauDeBord"> Tableau de bord : </a> </li> 
		</ul>
	</div>
