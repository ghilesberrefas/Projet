

<?php
	$title= "GESTION DES TYPES D'IDENTIFICATION" ; 
	include ("../trame/header.php");
?>
<div class="row">
	<?php 
		include ("menuGestion.php");
    ?>	
    <div class="container col-md-8" id="con5">		
			<h3>liste des type d'identification : </h3>
			<div class="container col-md-12 ">
			<table class="table">
			   <tr>
			   		<th>Id</th>
			        <th>Nom</th>
			        <th>Option 1</th>
			        <th>Option 2</th>
		       </tr>

			<?php
				$i=1;
				while ($data = $itypes->fetch()){
			?>	
			   <tr>

					<td> <?= $i ?>  </td> 
					<td> <?= $data['nom'] ?> </td>
					<td><a href="../view/page13a.php?tid=<?=$data['tid'] ?>">modifier </a></td>
					<td><a href="../controlleur/page9c.php?tid=<?=$data['tid'] ?>">supprimer </a></td>
									

			   </tr>
			<?php
					$i++;	
				}

				$itypes->closeCursor() ; 
			?>
			</table>
			</div> 
			<form action="../view/page12a.php" method="post">
				<p>cliquer sur le boton pour ajouter des type d'identification </p>
				<button type="submit" class="btn btn-primary">Ajouter</button>
			</form>	

	</div> 
</div> 		
<?php 
	include ("../trame/footer.php");
?>

