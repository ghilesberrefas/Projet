<?php 
$title= "Ajouter une PERSONNE" ; 
include ("../trame/header.php");
?>
	
<div class="container">	
	
	<p> Veuillez indiquer les cordonnées de la nouvelle personne.</p> 
	<form action="../controlleur/page11c.php" method="post">
			<div class="form-group">
				<label for ="nom"> Nom : </label>
				<input type="text" name="nom" class="form-control" id="nom">
			</div>
			<div class="form-group">
				<label for ="prenom"> Prénom : </label>
				<input type="text" name="prenom" class="form-control " id="prenom">
			</div>	
			<div class="form-group">
				<label for ="identification"> Choisiez un moyen d'identification : </label>
			</div>
			<div class="form-group row">
				<select name = "identification" class="form-control col-3"id="identification">
				<?php
					
					while($data=$itypes->fetch()){
				?>
	 					<option value="<?= $data['nom'] ?>"> <?= $data['nom'] ?>  </option> 
				<?php 
					}
					$itypes->closeCursor() ; 
			     ?> 
				</select> 
				<label for ="valeur"></label>
				<input type="text" name="valeur">
			</div>		
			<button type="submit" class="btn btn-primary">Ajouter</button>
	</form>
</div>
<?php 
include ("../trame/footer.php");
?>