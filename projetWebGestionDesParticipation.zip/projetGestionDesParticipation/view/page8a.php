

<?php
	$title= "GESTION DES PERSONNES" ; 
	include ("../trame/header.php");
?>
<div class="row">
	<?php 
		include ("menuGestion.php");
    ?>	
    <div class="container col-md-8" id="con5">	
		<h3>Liste des personnes : </h3>
		<small id="emailHelp" class="form-text text-muted">Cliquez sur le nom de la personne pour plus d'informations.</small>
		<div class="container col-md-12 ">
			<table class="table">
			   <tr>
			   		<th>Id</th>
			        <th>Nom</th>
			        <th>Prenom </th>
			        <th>Option 1</th>
			        <th>Option 2</th>
		       </tr>

			<?php
				$i=1 ;
				while ($data = $personnes->fetch()){ 
			?>	
				</tr>
			   		<td> <?= $i?>  </td>
					<td> <a href="../controlleur/page13c.php?pid=<?=$data['pid'] ?>"> <?= $data['nom'] ?> 	</a> </td> 
					<td> <a href="../controlleur/page13c.php?pid=<?=$data['pid'] ?>"> <?= $data['prenom'] ?></a> </td>
					<td><a href="../view/page9a.php?pid=<?=$data['pid'] ?>">Modifier </a></td>
					<td><a href="../controlleur/page9c.php?pid=<?=$data['pid'] ?>">Supprimer </a></td>		
			   </tr>
			<?php
				$i++;
				}
				$personnes->closeCursor() ; 
			?>
			</table>
	  	</div>
		<form action="../controlleur/page12c.php" method="post">
			<p>cliquer sur le boton pour ajouter des personnes </p>
			<button type="submit" class="btn btn-primary">Ajouter</button>
		</form>	
	</div> 
</div> 
<?php 
	include ("../trame/footer.php");
?>

