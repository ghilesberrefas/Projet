
<?php 
	$title= "Modifier une identification a une PERSONNE" ; 
	include ("../trame/header.php");
?>

<div class="d-flex justify-content-center">   
	<form action="../controlleur/page10c.php?ppid=<?= $pid ?>&identification=<?= $identification ?>" method="post">
		<div class="form-group">
			<label for ="valeur1"> Veuillez indiquer la nouvelle valeur :</label>
			<input type="text" class="form-control" name="valeur1" id="valeur1">
		</div>	
		<button type="submit" class="btn btn-primary">Modifer</button>
	</form>

</div>

<div class="container-fluid" id="con3">
		
	</div>



<?php 
	include ("../trame/footer.php");
?>