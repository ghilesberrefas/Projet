	


	<?php include ("../view/page21a.php");?>
		
	<h3>liste des participations : </h3>
	<div class="container col-md-12 ">
			<table class="table">
	  			<tr>
			   		<th>Id</th>
			        <th>Nom</th>
			        <th>Prenon</th>
			        <th>Evenement</th>
			        <th>Date De pointage</th>
			
		      	</tr>

				<?php	
					$i=1;
					while ($data = $participations->fetch()){
				?>	

	
		  		 <tr>

					<td> <?= $i ?>  </td> 
					<td> <?= $data['nom'] ?> </td>
					<td> <?= $data['prenom'] ?> </td>
					<td> <?= $data['intitule'] ?> </td>
					<td> <?= $data['date'] ?> </td>	

	     		 </tr>
	

	<?php
			$i++;	
		}

		$participations->closeCursor() ; 
	?>
	</table>
	</div> 

	<h3>Affichage des événements auxquels chaque personne a été inscrite,mais auxquels elle n’a pas participé:</h3>


	<?php $personnesInscriteMaisPasParticiper=personnesInscriteMaisPasParticiper() ; ?>

	<div class="container col-md-12 ">
			<table class="table">
	  			<tr>
			   		<th>Id</th>
			        <th>Nom</th>
			        <th>Prenon</th>
			        <th>Evenement</th>
			        
		      	</tr>
			<?php 
				$i=1;
				while ($data = $personnesInscriteMaisPasParticiper->fetch()){
			?>	
			   <tr>
					<td> <?= $i ?>  </td> 
					<td> <?= $data['nom'] ?> </td>
					<td> <?= $data['prenom'] ?> </td>
					<td> <?= $data['intitule'] ?> </td>
			   </tr>
	<?php
			$i++;	
		}
		$personnesInscriteMaisPasParticiper->closeCursor() ; 
	?>
		</table>
	</div> 

	<h3> Affichage des Personnes inscrites pour chaque evenmenent mais qui n’on pas participé: </h3>


	<?php  $evenementInscriteMaisPasParticiper=evenementInscriteMaisPasParticiper() ; ?>

	<div class="container col-md-12 ">
			<table class="table">
	  			<tr>
			   		<th>Id</th>
			   		<th>Evenement</th>
			        <th>Nom</th>
			        <th>Prenon</th>
			       
			    </tr>
			<?php
				$i=1;
				while ($data = $evenementInscriteMaisPasParticiper->fetch()){
			?>	
			   <tr>

					<td> <?= $i ?>  </td> 
					<td> <?= $data['intitule'] ?> </td>
					<td> <?= $data['nom'] ?> </td>
					<td> <?= $data['prenom'] ?> </td>
						

			   </tr>
			<?php
					$i++;	
				}

				$evenementInscriteMaisPasParticiper->closeCursor() ; 
			?>
			</table>
	</div> 

	</div> 
</div> 
	
<?php 

	include ("../trame/footer.php");
?>
