<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Participation à événements ouverts </title>

	</head>
	<body>
		<p>Veuillez indiquez ci_dessus vos cordonnés pour pourvoir participez a l'événement  <?php echo " " . $_GET['intitule'] ; ?> </p> 
		
	
		<form action="../controlleur/page2c.php" method="post">
				<label for ="nom"> Nom : </label>
				<input type="text" name="nom">
				<br/>
				<label for ="prenom"> Prénom : </label>
				<input type="text" name="prenom">
				<br/>	
				<input type="submit" value="Envoyer">
		</form>
	</body>
</html>