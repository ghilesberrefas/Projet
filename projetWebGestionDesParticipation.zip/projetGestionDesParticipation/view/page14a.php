

<?php
	$title= "GESTION DES EVENEMENTS" ; 
	include ("../trame/header.php");
?>	
<div class="row">
	<?php 
		include ("menuGestion.php");
    ?>	
    <div class="container col-md-9">		
			<h3>liste des evenemement : </h3>
			<div class="container col-md-12 ">
			<table class="table">
			   <tr>
			   		<th>Id</th>
			        <th>Intitule</th>
			        <th>DateDebut</th>
			        <th>DateFin</th>
			        <th>DateFin</th>
			        <th>Type</th>
			        <th>Option 1</th>
			        <th>Option 2</th>
		       </tr>

			<?php
				$i=1;
				while ($data = $evenement->fetch()){
			?>	
			   <tr>

					<td> <?= $i ?>  </td> 
					<td> <?= $data['intitule'] ?> </td>
					<td> <?= $data['dateDebut'] ?> </td>
					<td> <?= $data['dateFin'] ?> </td>
					<td> <?= $data['type'] ?> </td>
					<td> <?php if ($data['cid'] == 1 ) echo 'Examens' ; if ($data['cid'] == 2 ) echo 'Cours' ;
						if ($data['cid'] == 3 ) echo 'TPs' ;?> </td>
					<td><a href="../view/page16a.php?eid=<?=$data['eid'] ?>">modifier </a></td>
					<td><a href="../controlleur/page9c.php?eid=<?=$data['eid'] ?>">supprimer </a></td>
			   </tr>
			

			<?php
					$i++;	
				}

				$evenement->closeCursor() ; 
			?>
			</table>
			</div> 

			<form action="../view/page15a.php" method="post">
				<p>cliquer sur le boton pour ajouter des evenementns </p>
				<button type="submit" class="btn btn-primary">Ajouter</button>
			</form>	
	</div> 
</div> 

<?php 
	include ("../trame/footer.php");
?>

     