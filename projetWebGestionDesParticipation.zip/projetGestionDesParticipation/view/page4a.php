




	
	 	<div class="container col-md-4" id="menu_gestion">
				<p>  Bonjour <strong><em>  <?= $idm->getIdentity() ?> </em></strong>  Bienvenu dans Votre espace </p>
			<ul>
				<li> <a href="../controlleur/page5c.php?control=gdu"> Gestion des utilisateur :</a> </li>
				<li> <a href="../controlleur/page5c.php?control=gdp"> Gestion des personnes :</a></li>
				<li> <a href="../controlleur/page5c.php?control=gdi"> Gestion des types d’identification : </a> </li>
				<li> <a href="../controlleur/page5c.php?control=gde"> Gestin des événements : </a></li> 
				<li><a href="../controlleur/page5c.php?control=tableauDeBord"> Tableau de bord : </a> </li> 
			</ul>
	</div>

	<div class="container-fluid" id="con3">
		
	</div>
	<div class="container-fluid" id="con3">
		
	</div>
	<div class="container-fluid" id="con3">
		
	</div>





