<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Page d'acceuil </title>
        <link href="style.css" rel="stylesheet" /> 
    </head>
        
    <body>
    	<!-- <div id=user>
       		<p>S'indentifier en tant que utilisateur </p>
       		<form action="page1c.php" method="post">
				<label for ="login"> login : </label>
				<input type="text" name="login">
				<br/>
				<label for ="mdp"> mot de passe : </label>
				<input type="password" name="mdp">
				<br/>	
				<input type="submit" value="Se connecter">
			</form>
		</div> --> 
    	<div id=admin>

       		<p>S'indentifier : </p>

       		<form action="../controlleur/page4c.php" method="post">
			<label for ="login"> login : </label>
				<input type="text" name="login">
				<br/>
				<label for ="mdp"> mot de passe : </label>
				<input type="password" name="mdp">
				<br/>	
				<label for="conx">Connexion automatique </label>
				<input type="checkbox" name="conx">
				
				<input type="submit" value="Se connecter">
			</form>
		</div>
		<form action="../view/page3a.php" method="post">
				<input type="submit" value="S'inscrire">
		</form>
		<h1>les different événements </h1>
		<h2>Liste des événements Ouverts </h2>
		<?php
			while ($data = $eventOpen->fetch()){
		?>	
			<table>
			   <tr>
					<td> <?= $data['description'] ?>  </td> 
					<td> <?= $data['dateDebut'] ?> </td>
					<td> <?= $data['dateFin'] ?> </td>
					<td> <?= $data['type'] ?> </td>
					<td><a href="../view/page2a.php?eid=<?=$data['eid'] ?>&intitule=<?=$data['intitule'] ?>">Participer</a></td>

			   </tr>
			</table>
		<?php
			}
			$eventOpen->closeCursor() ; 
		?>
		<h2>Liste des événements Ferme</h2>
		<?php
			while ($data = $eventClose->fetch()){
		?>	
			<table>
			   <tr>
					<td> <?= $data['description'] ?>  </td> 
					<td> <?= $data['dateDebut'] ?> </td>
					<td> <?= $data['dateFin'] ?> </td>
					<td> <?= $data['type'] ?> </td>
					<td><a href="../view/page3a.php?eid=<?=$data['eid'] ?>&intitule=<?=$data['intitule'] ?>">Participer</a></td>

			   </tr>
			</table>
		<?php
			}
			$eventClose->closeCursor() ; 
		?>

		</form>
    </body>
</html>