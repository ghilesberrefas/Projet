<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Inscription </title>
        <link href="style.css" rel="stylesheet" /> 
    </head>
        
    <body>
        <form action="../controlleur/page3c.php" method="post">
	       	<p> Comment souhaitez vous vous inscrire ? </p>	
			<input type="radio" name="role" value="admin" id="admin" checked="checked" /> 
			<label for="administrateur">administrateur</label>
			<input type="radio" name="role" value="user" id="user" /> <label for="utilisateur">utilisateur</label>
			<br/>
			<label for ="login"> login : </label>
			<input type="text" name="login">
			<br/>
			<label for ="mdp"> mot de passe : </label>
			<input type="password" name="mdp">
			<br/>	
			<label for ="mdp1"> confirmation du mot de passe : </label>
			<input type="password" name="mdp1">
			<br/>	
			<input type="submit" value="Valider">
		</form>
        
    </body>
</html>