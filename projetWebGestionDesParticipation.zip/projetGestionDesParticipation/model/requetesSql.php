<?php
// Nouvelle fonction qui nous permet d'éviter de répéter du code
/*SELECT ptid , evenements.intitule , personnes.nom , personnes.prenom , date FROM `participations` join evenements on evenements.eid = participations.eid JOIN personnes ON personnes.pid = participations.pid WHERE participations.eid = 4*/


/*
SELECT inscriptions.pid , inscriptions.eid  
FROM inscriptions
where (inscriptions.pid , inscriptions.eid) not in (select participations.pid, participations.eid from participations)
*/
/*
SELECT personnes.nom , personnes.prenom , evenements.intitule
FROM inscriptions join personnes ON personnes.pid = inscriptions.pid join evenements on evenements.eid= inscriptions.eid 
where (inscriptions.pid , inscriptions.eid) not in (select participations.pid, participations.eid from participations)
*/
function dbConnect()
{   
    /*$dsn='u21815359'; 
    $username='u21815359';
    $password ='s8mxwrbUioCQ';*/
    require("../trame/db_config.php");
    try
    {
       // $db = new PDO("mysql:host=localhost;dbname=$dsn;charset=utf8", $username, $password);
        $db = new PDO($dsn, $username, $password);
        return $db;
    }
    catch(Exception $e)
    {
        die('Erreur : '.$e->getMessage());
    }
}

//Gestion des utilisateur 
function listUser()
{
    $db=dbConnect() ; 
    $req=$db->query('SELECT * FROM users ') ; 

    return  $req ; 

}
function addUser($login,$mdp,$role)
{   
    $db=dbConnect() ; 
    $req=$db->prepare('INSERT INTO users (login, mdp,role) VALUES (?,?,?) ');  
    $req->execute(array($login,$mdp,$role)) ; 
}
function editmdp($login,$mdp,$role)
{
    $db=dbConnect() ; 
    $req=$db->query('UPDATE users SET mdp= $mdp ');
}

//Gestion des événements 
function listEventOpen()
{
    $db=dbConnect() ; 
    $req=$db->query('SELECT * FROM evenements WHERE type = "ouvert"  ') ; 
    return  $req ; 
}
function listEventClose()
{
    $db=dbConnect() ; 
    $req=$db->query('SELECT * FROM evenements WHERE type = "ferme" ') ; 
    return  $req ; 
}

function listEvenement() 
{
    $db=dbConnect() ; 
    $req=$db->query('SELECT * FROM evenements') ; 
    return  $req ; 
}
function deleteEvenement($eid)
{
    $db=dbConnect() ; 
    $req=$db->prepare('DELETE FROM evenements WHERE eid = ?') ; 
    $req->execute(array($eid)) ; 
}
function addEvenement($intitule,$description,$dateDebut,$dateFin,$type,$cid)
{   
    $db=dbConnect() ; 
    $req=$db->prepare('INSERT INTO evenements (intitule,description, dateDebut,dateFin,type,cid) VALUES (?,?,?,?,?,?) ');  
    $req->execute(array($intitule,$description,$dateDebut,$dateFin,$type,$cid)) ; 
}

//Gestion des personne
function listPersonnes () 
{
    $db=dbConnect() ; 
    $req=$db->query('SELECT * FROM personnes ') ; 
    return  $req ; 
}
function editNom($nom){
    
}
function addpersonnes ($nom,$prenom){
    $db=dbConnect() ; 
    $req=$db->prepare('INSERT INTO personnes (nom,prenom) VALUES (?,?)') ; 
    $req->execute(array($nom,$prenom)) ; 

}
function detelePersonnes ($pid) {
     $db=dbConnect() ; 
    $req=$db->prepare('DELETE FROM personnes WHERE pid = ?') ; 
    $req->execute(array($pid)) ; 
}
//Gestion des types d'idantification 
function listItypes(){  
    $db=dbConnect() ; 
    $req=$db->query('SELECT * FROM itypes ') ; 

    return  $req ; 
}
function deleteItypes($tid){
    $db=dbConnect() ; 
    $req=$db->prepare('DELETE FROM itypes WHERE tid = ?') ; 
    $req->execute(array($tid)) ; 

}
function addItypes($nom){
    $db=dbConnect() ; 
    $req=$db->prepare('INSERT INTO itypes (nom) VALUES (?)') ; 
    $req->execute(array($nom)) ; 

}

function readTid($identifie){
    $db=dbConnect() ; 
    $req=$db->prepare('SELECT tid FROM itypes  WHERE nom = ? ') ; 
    $req->execute(array($identifie)) ; 
    return $req ; 
}
//Gestion des idantification 
function addIdentification($pid,$tid,$valeur) {
    $db=dbConnect() ; 
    $req=$db->prepare('INSERT INTO identifications (pid, tid, valeur) VALUES (?,?,?) ');
    $req->execute(array($pid,$tid,$valeur)) ; 
}
function deleteIdentification($pid) {
    $db=dbConnect() ; 
    $req=$db->prepare('DELETE FROM identifications WHERE pid = ?') ; 
    $req->execute(array($pid)) ; 

}
function listIdentification($pid){
    $db=dbConnect() ; 
    $req=$db->prepare('SELECT itypes.tid ,nom , valeur , pid FROM identifications JOIN itypes 
        ON identifications.tid = itypes.tid 
        WHERE identifications.pid = ? ') ; 
    $req->execute(array($pid)) ; 
    return $req ;
}   

// Gestion des partification 
function listdate() {
    $db=dbConnect() ; 
    $req=$db->query('SELECT DISTINCT date  FROM participations') ; 
    return  $req ; 
}
function listParticipations() {
    $db=dbConnect() ; 
    $req=$db->query('SELECT personnes.nom , personnes.prenom , evenements.intitule , participations.date FROM participations join personnes on personnes.pid = participations.pid join evenements ON participations.eid = evenements.eid') ; 
    return  $req ;    
}
function listParticipationsParEvenement($eid) {
    $db=dbConnect() ; 
    $req=$db->prepare('SELECT personnes.nom , personnes.prenom , evenements.intitule , participations.date FROM participations join personnes on personnes.pid = participations.pid join evenements ON participations.eid = evenements.eid WHERE participations.eid = ?') ; 
    $req->execute(array($eid)) ; 
    return  $req ;    
}
function listParticipationsParPersonne($pid){
    $db=dbConnect() ; 
    $req=$db->prepare('SELECT personnes.nom , personnes.prenom , evenements.intitule , participations.date FROM participations join personnes on personnes.pid = participations.pid join evenements ON participations.eid = evenements.eid WHERE participations.pid = ?') ; 
    $req->execute(array($pid)) ; 
    return  $req ;   

}

function listParticipationsParDate($date){

      $db=dbConnect() ; 
    $req=$db->prepare('SELECT personnes.nom , personnes.prenom , evenements.intitule , participations.date FROM participations join personnes on personnes.pid = participations.pid join evenements ON participations.eid = evenements.eid WHERE participations.date = ?') ; 
    $req->execute(array($date)) ; 
    return  $req ;   


}

function listParticipationsParEvenementEtPersonnes($eid , $pid ){
        $db=dbConnect() ; 
    $req=$db->prepare('SELECT personnes.nom , personnes.prenom , evenements.intitule , participations.date FROM participations join personnes on personnes.pid = participations.pid join evenements ON participations.eid = evenements.eid WHERE participations.eid = ? AND participations.pid = ? ') ; 
    $req->execute(array($eid,$pid)) ; 
    return  $req ;    


}
function listParticipationsParEvenementEtDate($eid,$date){
            $db=dbConnect() ; 
    $req=$db->prepare('SELECT personnes.nom , personnes.prenom , evenements.intitule , participations.date FROM participations join personnes on personnes.pid = participations.pid join evenements ON participations.eid = evenements.eid WHERE participations.eid = ? AND participations.date = ? ') ; 
    $req->execute(array($eid,$date)) ; 
    return  $req ; 


}

function listParticipationsParPersonnesEtDate($pid,$date) {
        $db=dbConnect() ; 
    $req=$db->prepare('SELECT personnes.nom , personnes.prenom , evenements.intitule , participations.date FROM participations join personnes on personnes.pid = participations.pid join evenements ON participations.eid = evenements.eid WHERE participations.pid = ? AND participations.date = ? ') ; 
    $req->execute(array($pid,$date)) ; 
    return  $req ; 
}

function listParticipationsParEvenementEtpersonnesEtDate($eid , $pid , $date){
           $db=dbConnect() ; 
    $req=$db->prepare('SELECT personnes.nom , personnes.prenom , evenements.intitule , participations.date FROM participations join personnes on personnes.pid = participations.pid join evenements ON participations.eid = evenements.eid WHERE participations.eid = ? AND participations.pid = ? AND participations.date = ? ') ; 
    $req->execute(array($eid,$pid,$date)) ; 
    return  $req ; 
}

function personnesInscriteMaisPasParticiper(){
    $db=dbConnect() ; 
    $req=$db->query('SELECT personnes.nom , personnes.prenom , evenements.intitule 
FROM inscriptions join personnes ON personnes.pid = inscriptions.pid join evenements on evenements.eid= inscriptions.eid 
where (inscriptions.pid , inscriptions.eid) not in (select participations.pid, participations.eid from participations) ') ; 

    return  $req ; 

}
function evenementInscriteMaisPasParticiper(){
    $db=dbConnect() ; 
        $req=$db->query('SELECT evenements.intitule , personnes.nom , personnes.prenom  
    FROM inscriptions join personnes ON personnes.pid = inscriptions.pid join evenements on evenements.eid= inscriptions.eid 
    where (inscriptions.pid , inscriptions.eid) not in (select participations.pid, participations.eid from participations) ') ; 

    return  $req ; 

}