<!DOCTYPE html>
<html>
<head>
    <title>Root page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" >
   	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" ></script>	

	<link rel="stylesheet" type="text/css" href="../css/style.css"></li>
	

</head>
<body>
<div class="row">

	<div class="container-fluid col-sm-2"  id="con1">
		
	</div>

	<div class="container-fluid col-sm-10" id="con2">
		
	</div>

</div>

	<div class="container-fluid" id="con3">
		
	</div>
       

    <div class="container">
		  <h1 class="display-4">Bonjour ! bienvenu sur mon site. </h1>

		  <p class="lead">Le site vous permetra  la Gestion des participation </p>
		  <p>Si vous faite partie d'une administration et vous souhaitez gerer des participations a des evenments ce site est faite pour vous.</p>
		  <a class="btn btn-primary btn-lg" href="home.php" role="button" id="button1">CE CONNECTER</a>
</div>

</body>




<div class="container-fluid" id="con4">
		
	</div>


</html>