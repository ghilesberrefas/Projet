<!DOCTYPE html>

<html>

<head>
	<meta charset="utf-8"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?= $title??"" ?></title>
	 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" >
   	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" ></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

	<link rel="stylesheet" type="text/css" href="../css/style.css"></li>


</head>

<body>

<div class="row">
	<div class="container-fluid col-sm-2"  id="con1">
		
	</div>
	<div class="container-fluid col-sm-10" id="con2">

		<div class="row d-flex justify-content-end" id="nav1">
			<ul class="nav">
			  <li class="nav-item">
			    <a class="nav-link active" href="../trame/home.php">Acceuil</a>
			  </li>
			  <li class="nav-item">
			    <a class="nav-link" href="#">Aide</a>
			  </li>
			  <li class="nav-item">
			    <a class="nav-link" href="#">Contact</a>
			  </li>
			  <li class="nav-item">
			    <a class="nav-link Disabledabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
			  </li>
			</ul>		
		
	
			          
	  		<div class="dropdown col-1">
			    <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown"><svg class="bi bi-list" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M2.5 11.5A.5.5 0 013 11h10a.5.5 0 010 1H3a.5.5 0 01-.5-.5zm0-4A.5.5 0 013 7h10a.5.5 0 010 1H3a.5.5 0 01-.5-.5zm0-4A.5.5 0 013 3h10a.5.5 0 010 1H3a.5.5 0 01-.5-.5z" clip-rule="evenodd"/></svg></button>
						    <ul class="dropdown-menu">
						      <li><a href="#">Profil</a></li>
						      <li><a href="#">Parametre</a></li>
						      <li><a href="<?= $pathFor['logout'] ?>" title="Logout"> Déconnexion </a></li>
						    </ul>
		  </div>
		</div>
		

	</div>
</div>



	<div class="container-fluid" id="con3">
		
	</div>