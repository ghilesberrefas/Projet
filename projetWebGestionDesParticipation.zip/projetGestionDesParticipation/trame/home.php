<?php



require("auth/EtreAuthentifie.php");

/*$title = 'Accueil';

include("header.php*/

    $title= "Bienvenu dans Votre espace " ; 

include ("../trame/header.php");

include("../view/page4a.php") ; 
?>



<?php

//echo "Hello " . $idm->getIdentity().". Your uid is: ". $idm->getUid() .". Your role is: ".$idm->getRole();

//echo "Escaped values: ".$e_($ci->idm->getIdentity());

include("footer.php");