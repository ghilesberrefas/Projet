<?php

$authTableData = [
    'table' => 'users',
    'idfield' => 'login',
    'cfield' => 'mdp',
    'uidfield' => 'uid',
    'rfield' => 'role',
];

$pathFor = [
    "login"  => "/~u21815359/projetGestionDesParticipation/trame/login.php",
    "logout" => "/~u21815359/projetGestionDesParticipation/trame/logout.php",
    "adduser" => "/~u21815359/projetGestionDesParticipation/trame/adduser.php",
    "root"   => "/~u21815359/projetGestionDesParticipation/trame",
];

const SKEY = '_Redirect';