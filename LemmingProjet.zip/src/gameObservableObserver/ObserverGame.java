package gameObservableObserver;

public interface ObserverGame {
	public void update();
}
