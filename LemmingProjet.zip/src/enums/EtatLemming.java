package enums;

public enum EtatLemming { 
	DIED,ALIVE,SAVED;
}
