package enums;

public enum Direction {
	LEFT,RIGHT;
}
